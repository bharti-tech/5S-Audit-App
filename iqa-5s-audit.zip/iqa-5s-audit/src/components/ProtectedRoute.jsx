import { Navigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

// requireRole: optional array like ['editor','admin']. If omitted, any signed-in user may view.
export function ProtectedRoute({ children, requireRole }) {
  const { session, role, loading } = useAuth();

  if (loading) return <div className="loading-screen">Loading…</div>;
  if (!session) return <Navigate to="/login" replace />;

  if (requireRole && !requireRole.includes(role)) {
    return (
      <div className="denied card">
        <h2>Access restricted</h2>
        <p>
          Your account role is <b>{role}</b>. This page needs{' '}
          {requireRole.length === 1 ? requireRole[0] : requireRole.join(' or ')} access.
        </p>
        <p className="muted">Ask an admin to change your role from the Admin page.</p>
      </div>
    );
  }

  return children;
}

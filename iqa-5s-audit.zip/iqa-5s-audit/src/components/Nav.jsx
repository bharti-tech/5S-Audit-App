import { NavLink } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

export default function Nav() {
  const { user, role, signOut } = useAuth();
  const canEdit = role === 'editor' || role === 'admin';

  return (
    <header className="topbar">
      <div className="brand">
        <div className="brand-mark">5S</div>
        <div>
          <h1>I&amp;QA 5S Audit</h1>
          <div className="sub">{user?.email} · <span className="role-pill">{role}</span></div>
        </div>
      </div>
      <nav className="tabs">
        <NavLink to="/" end className={({isActive}) => isActive ? 'tab-btn active' : 'tab-btn'}>Dashboard</NavLink>
        {canEdit && (
          <NavLink to="/audit" className={({isActive}) => isActive ? 'tab-btn active' : 'tab-btn'}>New Audit</NavLink>
        )}
        {canEdit && (
          <NavLink to="/questions" className={({isActive}) => isActive ? 'tab-btn active' : 'tab-btn'}>Manage Questions</NavLink>
        )}
        {role === 'admin' && (
          <NavLink to="/admin" className={({isActive}) => isActive ? 'tab-btn active' : 'tab-btn'}>Admin</NavLink>
        )}
        <button className="tab-btn" onClick={signOut}>Sign Out</button>
      </nav>
    </header>
  );
}

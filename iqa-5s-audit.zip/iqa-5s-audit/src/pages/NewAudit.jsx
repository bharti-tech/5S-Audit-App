import { useEffect, useState } from 'react';
import { supabase } from '../supabaseClient';
import { useAuth } from '../hooks/useAuth';

export default function NewAudit() {
  const { user } = useAuth();
  const [pillars, setPillars] = useState([]);
  const [scores, setScores] = useState({});
  const [meta, setMeta] = useState({
    area: '',
    auditor: '',
    owner: '',
    date: new Date().toISOString().slice(0, 10),
  });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loadError, setLoadError] = useState('');

  useEffect(() => {
    loadCriteria();
  }, []);

  async function loadCriteria() {
    const { data, error } = await supabase
      .from('criteria_template')
      .select('*')
      .order('pillar_key')
      .order('sort_order');
    if (error) {
      setLoadError(error.message);
      return;
    }
    const grouped = {};
    (data || []).forEach((row) => {
      if (!grouped[row.pillar_key]) {
        grouped[row.pillar_key] = { key: row.pillar_key, label: row.pillar_label, questions: [] };
      }
      grouped[row.pillar_key].questions.push(row);
    });
    setPillars(Object.values(grouped));
  }

  function setField(qId, field, value) {
    setScores((prev) => ({
      ...prev,
      [qId]: { score: null, remarks: '', action: '', resp: '', status: 'Open', ...(prev[qId] || {}), [field]: value },
    }));
  }

  function pillarAverage(pillar) {
    const vals = pillar.questions.map((q) => scores[q.id]?.score).filter((v) => v != null);
    if (!vals.length) return null;
    return vals.reduce((a, b) => a + b, 0) / vals.length;
  }
  function overall() {
    const avgs = pillars.map(pillarAverage).filter((v) => v != null);
    if (!avgs.length) return null;
    return avgs.reduce((a, b) => a + b, 0) / avgs.length;
  }

  async function handleSave() {
    setSaving(true);
    const pillarScores = {};
    pillars.forEach((p) => (pillarScores[p.key] = pillarAverage(p)));
    const { error } = await supabase.from('audits').insert({
      created_by: user.id,
      area: meta.area || 'Unnamed Area',
      auditor: meta.auditor || user.email,
      owner: meta.owner || null,
      audit_date: meta.date,
      overall: overall(),
      pillar_scores: pillarScores,
      details: scores,
    });
    setSaving(false);
    if (error) {
      alert('Save failed: ' + error.message);
      return;
    }
    setSaved(true);
    setScores({});
    setTimeout(() => setSaved(false), 3000);
  }

  return (
    <div className="page">
      <div className="card">
        <h2>Audit Ticket</h2>
        <div className="meta-grid">
          <label>
            Area / Workstation
            <input value={meta.area} onChange={(e) => setMeta({ ...meta, area: e.target.value })} />
          </label>
          <label>
            Auditor
            <input value={meta.auditor} onChange={(e) => setMeta({ ...meta, auditor: e.target.value })} placeholder={user?.email} />
          </label>
          <label>
            Area Owner
            <input value={meta.owner} onChange={(e) => setMeta({ ...meta, owner: e.target.value })} />
          </label>
          <label>
            Date
            <input type="date" value={meta.date} onChange={(e) => setMeta({ ...meta, date: e.target.value })} />
          </label>
        </div>
      </div>

      {loadError && <p className="error-text">Could not load the question list: {loadError}</p>}

      {pillars.map((p) => {
        const avg = pillarAverage(p);
        return (
          <div className="card pillar-card" key={p.key}>
            <h3>
              {p.label} <span className="pillar-avg">{avg == null ? '–' : avg.toFixed(1)}</span>
            </h3>
            {p.questions.map((q) => (
              <div className="criterion" key={q.id}>
                <div className="crit-row">
                  <span className="crit-text">{q.question}</span>
                  <div className="score-btns">
                    {[1, 2, 3, 4, 5].map((n) => (
                      <button
                        key={n}
                        type="button"
                        className={scores[q.id]?.score === n ? 'score-btn sel' : 'score-btn'}
                        onClick={() => setField(q.id, 'score', n)}
                      >
                        {n}
                      </button>
                    ))}
                  </div>
                </div>
                <textarea
                  className="remarks-input"
                  placeholder="Remarks / corrective action (optional)"
                  value={scores[q.id]?.remarks || ''}
                  onChange={(e) => setField(q.id, 'remarks', e.target.value)}
                  rows={2}
                />
              </div>
            ))}
          </div>
        );
      })}

      {pillars.length > 0 && (
        <div className="card save-card">
          <div className="overall-readout">
            Overall: <b>{overall() == null ? '–' : overall().toFixed(2)}</b> / 5
          </div>
          <button className="btn btn-primary" disabled={saving} onClick={handleSave}>
            {saving ? 'Saving…' : 'Save Audit'}
          </button>
          {saved && <p className="success-text">Saved to the shared log.</p>}
        </div>
      )}
    </div>
  );
}

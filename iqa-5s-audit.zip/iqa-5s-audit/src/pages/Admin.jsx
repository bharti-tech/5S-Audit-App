import { useEffect, useState } from 'react';
import { supabase } from '../supabaseClient';

export default function Admin() {
  const [profiles, setProfiles] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    load();
  }, []);

  async function load() {
    const { data, error } = await supabase.from('profiles').select('*').order('email');
    if (error) setError(error.message);
    setProfiles(data || []);
  }

  async function changeRole(id, role) {
    const { error } = await supabase.from('profiles').update({ role }).eq('id', id);
    if (error) setError(error.message);
    load();
  }

  return (
    <div className="page">
      <div className="card">
        <h2>Manage User Roles</h2>
        <p className="muted">
          Viewer = read-only. Editor = can submit audits and edit questions. Admin = editor + can
          change roles here. Enforced by database policies, not just this page.
        </p>
        {error && <p className="error-text">{error}</p>}
        <table>
          <thead><tr><th>Email</th><th>Role</th></tr></thead>
          <tbody>
            {profiles.map((p) => (
              <tr key={p.id}>
                <td>{p.email}</td>
                <td>
                  <select value={p.role} onChange={(e) => changeRole(p.id, e.target.value)}>
                    <option value="viewer">Viewer</option>
                    <option value="editor">Editor</option>
                    <option value="admin">Admin</option>
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

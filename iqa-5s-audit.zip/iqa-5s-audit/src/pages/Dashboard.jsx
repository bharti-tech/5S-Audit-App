import { useEffect, useMemo, useState } from 'react';
import { Line, Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  LineElement,
  PointElement,
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend,
} from 'chart.js';
import { supabase } from '../supabaseClient';

ChartJS.register(LineElement, PointElement, BarElement, CategoryScale, LinearScale, Tooltip, Legend);

const PILLAR_KEYS = ['sort', 'setinorder', 'shine', 'standardize', 'sustain'];
const PILLAR_LABELS = {
  sort: '1S Sort',
  setinorder: '2S Set in Order',
  shine: '3S Shine',
  standardize: '4S Standardize',
  sustain: '5S Sustain',
};
const PALETTE = ['#D98E2B', '#4C7A52', '#B4423B', '#3B6E8F', '#8B5FBF', '#C97A3C', '#5C8A72'];

export default function Dashboard() {
  const [audits, setAudits] = useState([]);
  const [areaFilter, setAreaFilter] = useState('');
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setLoading(true);
    const { data, error } = await supabase.from('audits').select('*').order('audit_date', { ascending: false });
    if (error) setLoadError(error.message);
    else setAudits(data || []);
    setLoading(false);
  }

  const areas = useMemo(() => [...new Set(audits.map((a) => a.area))], [audits]);
  const filtered = areaFilter ? audits.filter((a) => a.area === areaFilter) : audits;

  const avgOverall = filtered.length
    ? filtered.reduce((s, a) => s + (a.overall || 0), 0) / filtered.length
    : null;

  const trendData = useMemo(() => {
    const dates = [...new Set(filtered.map((a) => a.audit_date))].sort((a, b) => new Date(a) - new Date(b));
    const seriesAreas = areaFilter ? [areaFilter] : areas;
    return {
      labels: dates,
      datasets: seriesAreas.map((area, i) => ({
        label: area,
        data: dates.map((d) => {
          const rec = filtered.find((a) => a.area === area && a.audit_date === d);
          return rec ? rec.overall : null;
        }),
        borderColor: PALETTE[i % PALETTE.length],
        backgroundColor: PALETTE[i % PALETTE.length] + '26',
        spanGaps: true,
        tension: 0.3,
        pointRadius: 4,
      })),
    };
  }, [filtered, areas, areaFilter]);

  const pillarData = useMemo(() => {
    const avgs = PILLAR_KEYS.map((k) => {
      const vals = filtered.map((a) => a.pillar_scores?.[k]).filter((v) => v != null);
      return vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
    });
    return {
      labels: PILLAR_KEYS.map((k) => PILLAR_LABELS[k]),
      datasets: [{ label: `Average (n=${filtered.length})`, data: avgs, backgroundColor: PALETTE }],
    };
  }, [filtered]);

  return (
    <div className="page">
      <div className="kpi-row">
        <div className="kpi-card"><div className="n">{audits.length}</div><div className="l">Audits Logged</div></div>
        <div className="kpi-card"><div className="n">{avgOverall == null ? '–' : avgOverall.toFixed(2)}</div><div className="l">Avg Overall</div></div>
        <div className="kpi-card"><div className="n">{areas.length}</div><div className="l">Areas Tracked</div></div>
      </div>

      <div className="card">
        <div className="dash-toolbar">
          <h2 style={{ margin: 0 }}>Audit Log</h2>
          <select value={areaFilter} onChange={(e) => setAreaFilter(e.target.value)}>
            <option value="">All areas</option>
            {areas.map((a) => (
              <option key={a} value={a}>{a}</option>
            ))}
          </select>
        </div>
        {loadError && <p className="error-text">{loadError}</p>}
        {loading ? (
          <p className="muted">Loading…</p>
        ) : filtered.length === 0 ? (
          <p className="muted">No audits logged yet.</p>
        ) : (
          <table>
            <thead><tr><th>Date</th><th>Area</th><th>Auditor</th><th>Overall</th></tr></thead>
            <tbody>
              {filtered.map((a) => (
                <tr key={a.id}>
                  <td>{a.audit_date}</td>
                  <td>{a.area}</td>
                  <td>{a.auditor}</td>
                  <td>{a.overall == null ? '–' : a.overall.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="card">
        <h2>Score Trend by Area</h2>
        {filtered.length ? (
          <div className="chart-box"><Line data={trendData} options={{ maintainAspectRatio: false, scales: { y: { min: 0, max: 5 } } }} /></div>
        ) : <p className="muted">No data yet.</p>}
      </div>

      <div className="card">
        <h2>Average by Pillar</h2>
        {filtered.length ? (
          <div className="chart-box"><Bar data={pillarData} options={{ maintainAspectRatio: false, scales: { y: { min: 0, max: 5 } } }} /></div>
        ) : <p className="muted">No data yet.</p>}
      </div>
    </div>
  );
}

import { useEffect, useState } from 'react';
import { supabase } from '../supabaseClient';

export default function QuestionManager() {
  const [rows, setRows] = useState([]);
  const [newText, setNewText] = useState({});
  const [error, setError] = useState('');

  useEffect(() => {
    load();
  }, []);

  async function load() {
    const { data, error } = await supabase
      .from('criteria_template')
      .select('*')
      .order('pillar_key')
      .order('sort_order');
    if (error) setError(error.message);
    setRows(data || []);
  }

  const grouped = rows.reduce((acc, r) => {
    if (!acc[r.pillar_key]) acc[r.pillar_key] = { label: r.pillar_label, items: [] };
    acc[r.pillar_key].items.push(r);
    return acc;
  }, {});

  async function addQuestion(pillarKey, pillarLabel) {
    const text = (newText[pillarKey] || '').trim();
    if (!text) return;
    const maxOrder = Math.max(0, ...(grouped[pillarKey]?.items.map((i) => i.sort_order) || [0]));
    const { error } = await supabase
      .from('criteria_template')
      .insert({ pillar_key: pillarKey, pillar_label: pillarLabel, question: text, sort_order: maxOrder + 1 });
    if (error) setError(error.message);
    setNewText({ ...newText, [pillarKey]: '' });
    load();
  }

  async function updateQuestion(id, text) {
    if (!text.trim()) return;
    const { error } = await supabase.from('criteria_template').update({ question: text.trim() }).eq('id', id);
    if (error) setError(error.message);
    load();
  }

  async function deleteQuestion(id, label) {
    if (!window.confirm(`Remove "${label}"?`)) return;
    const { error } = await supabase.from('criteria_template').delete().eq('id', id);
    if (error) setError(error.message);
    load();
  }

  return (
    <div className="page">
      <div className="card">
        <h2>Manage Questions</h2>
        <p className="muted">
          Changes here are saved to the database and enforced by row-level security — only editor
          and admin accounts can reach this page or make these changes, even via direct API calls.
        </p>
        {error && <p className="error-text">{error}</p>}
      </div>

      {Object.entries(grouped).map(([key, g]) => (
        <div className="card" key={key}>
          <h3>{g.label}</h3>
          {g.items.map((item) => (
            <div className="crit-row edit-row" key={item.id}>
              <input
                defaultValue={item.question}
                onBlur={(e) => e.target.value !== item.question && updateQuestion(item.id, e.target.value)}
              />
              <button className="crit-icon-btn crit-delete" onClick={() => deleteQuestion(item.id, item.question)} title="Remove">
                &times;
              </button>
            </div>
          ))}
          <div className="add-question-form">
            <input
              placeholder="Type a new question…"
              value={newText[key] || ''}
              onChange={(e) => setNewText({ ...newText, [key]: e.target.value })}
              onKeyDown={(e) => e.key === 'Enter' && addQuestion(key, g.label)}
            />
            <button className="btn btn-primary btn-small" onClick={() => addQuestion(key, g.label)}>
              + Add
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}

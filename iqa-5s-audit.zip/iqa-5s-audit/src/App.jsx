import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './hooks/useAuth';
import { ProtectedRoute } from './components/ProtectedRoute';
import Nav from './components/Nav';
import Login from './pages/Login';
import NewAudit from './pages/NewAudit';
import Dashboard from './pages/Dashboard';
import QuestionManager from './pages/QuestionManager';
import Admin from './pages/Admin';

function Shell({ children }) {
  return (
    <div className="app-shell">
      <Nav />
      <main>{children}</main>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route
            path="/"
            element={
              <ProtectedRoute>
                <Shell><Dashboard /></Shell>
              </ProtectedRoute>
            }
          />
          <Route
            path="/audit"
            element={
              <ProtectedRoute requireRole={['editor', 'admin']}>
                <Shell><NewAudit /></Shell>
              </ProtectedRoute>
            }
          />
          <Route
            path="/questions"
            element={
              <ProtectedRoute requireRole={['editor', 'admin']}>
                <Shell><QuestionManager /></Shell>
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin"
            element={
              <ProtectedRoute requireRole={['admin']}>
                <Shell><Admin /></Shell>
              </ProtectedRoute>
            }
          />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
